﻿using GFHelper.Models;
using System.Collections.Generic;

namespace GFHelper
{
    class Data
    {
        public static UserInfo userInfo = new UserInfo();
        public static Dictionary<int, GunInfo> gunInfo = new Dictionary<int, GunInfo>();
        public static Dictionary<int, OperationInfo> operationInfo = new Dictionary<int, OperationInfo>();
        public static SortedDictionary<int, Dictionary<int, GunWithUserInfo>> teamInfo = new SortedDictionary<int, Dictionary<int, GunWithUserInfo>>();
    }
}
