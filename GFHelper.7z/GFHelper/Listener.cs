﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nekoxy;
using System.Windows.Controls;
using Codeplex.Data;
using System.Windows.Threading;
using System.Web;
using System.Collections.Specialized;

namespace GFHelper
{
    class Listener
    {

        private InstanceManager im;

        private string token;//讲道理，这就是sign
        private string uid;
        private long timeoffset;

        public Listener(InstanceManager im)
        {

            this.im = im;
            

            token = "";
            timeoffset = 0;
        }

        ~Listener()
        {
            HttpProxy.Shutdown();
        }

        public void Shutdown()
        {
            HttpProxy.Shutdown();
        }

        public void startProxy(int port)
        {

            if (!im.serverHelper.downloadServerInfo())
            {
                im.uiHelper.setStatusBarText("服务器列表获取失败！");
                return;
            }
            
            int servernum = im.serverHelper.getServersNumber();

            HttpProxy.Shutdown();

            HttpProxy.AfterSessionComplete += (obj) => Task.Run(() => { processData(obj); });
            HttpProxy.Startup(port, false, false);

            string proxyaddr = String.Format("{0}:{1}", im.serverHelper.getLocalAddress(), port);

            im.uiHelper.setStatusBarText(String.Format("代理在{0}上开启成功，等待连接……已添加{1}个服务器", proxyaddr, servernum));

        }


        private void processData(Session obj)
        {
            string host = obj.Request.Headers.Host;
            KeyValuePair<string, string> server = im.serverHelper.getServerFromDictionary(host);

            if (server.Key == "" && server.Value == "") return;

            //dirty code
            string api = obj.Request.RequestLine.URI.Substring(server.Key.Length - ("http://" + host).Length);
            Console.WriteLine(api);
            switch (api)
            {
                case RequestUrls.GetDigitalUid:
                    {
                        string data = obj.Response.BodyAsString;
                        string decoded = AuthCode.Decode(data, "yundoudou");
                        Console.WriteLine(decoded);
                        dynamic jsonobj = DynamicJson.Parse(decoded);
                        token = jsonobj.sign;
                        uid = jsonobj.uid;

                        //wtf?
                        Models.SimpleUserInfo.sign = token;
                        Models.SimpleUserInfo.uid = uid;

                        im.uiHelper.setStatusBarText_InThread(String.Format("已登录服务器: {0}，token: {1}，uid: {2}", server.Value, token, uid));
                        Models.SimpleUserInfo.host = server.Key;
                        break;
                    }


                case RequestUrls.GetServerTime://同步服务器时间
                    {
                        if (String.IsNullOrEmpty(token) || String.IsNullOrEmpty(uid))
                        {
                            im.uiHelper.setStatusBarText_InThread("未获取到token！请重新登录游戏以使本工具正常工作！");
                            break;
                        }
                        if (String.IsNullOrEmpty(token)) break;
                        string decoded = AuthCode.Decode(obj.Response.BodyAsString, token);
                        dynamic jsonobj = DynamicJson.Parse(decoded);

                        Console.WriteLine("Server: " + jsonobj.now + " \nClient: " + CommonHelper.ConvertDateTimeInt(DateTime.Now));
                        timeoffset = Convert.ToInt64(jsonobj.now) - CommonHelper.ConvertDateTimeInt(DateTime.Now);
                        Console.WriteLine("Set timeoffset: " + timeoffset);
                        break;
                    }


                default:
                    {
                        if (String.IsNullOrEmpty(token) || String.IsNullOrEmpty(uid))
                        {
                            im.uiHelper.setStatusBarText_InThread("未获取到token！请重新登录游戏以使本工具正常工作！");
                        }
                        else
                        {
                            try {
                                NameValueCollection clientdata = new NameValueCollection();
                                string serverdata = AuthCode.Decode(obj.Response.BodyAsString, token);

                                if (String.IsNullOrEmpty(serverdata))//没有加密
                                    serverdata = obj.Response.BodyAsString;

                                if (!String.IsNullOrEmpty(obj.Response.BodyAsString))
                                {

                                    clientdata = HttpUtility.ParseQueryString(obj.Request.BodyAsString);
                                    if (clientdata.AllKeys.Contains("outdatacode"))
                                    {
                                        clientdata["outdatacode"] = AuthCode.Decode(clientdata["outdatacode"], token, timeoffset);
                                        Console.WriteLine("outdatacode: " + clientdata["outdatacode"]);
                                        
                                    }
                                }

                                if(serverdata.Length < 100)
                                Console.WriteLine("Serverdata: " + serverdata);
                                processMainData(api, clientdata, serverdata);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        }
                        break;
                    }

            }
        }


        public void processMainData(string api, NameValueCollection client, string server)
        {
            switch (api)
            {
                case RequestUrls.GetUserInfo:
                    {
                        im.dataHelper.ReadUserInfo(server);
                        im.uiHelper.setUserInfo(Data.userInfo);
                        im.autoOperation.SetTeamInfo();
                        break;
                    }
                case RequestUrls.DevelopGun:
                    {
                        dynamic clientjson = DynamicJson.Parse(client["outdatacode"]);
                        dynamic serverjson = DynamicJson.Parse(server);

                        int buildslot = Convert.ToInt32(clientjson.build_slot);
                        int resultid = Convert.ToInt32(serverjson.gun_id);
                        im.uiHelper.setDevelopingTimer(im.timer, buildslot, resultid, CommonHelper.ConvertDateTimeInt(DateTime.Now));
                        im.uiHelper.setStatusBarText_InThread(String.Format("建造结果: {0} 于建造槽{1}", Data.gunInfo[0].name, buildslot));
                        break;
                    }


                case RequestUrls.FinishDevelopGun:
                    {
                        dynamic clientjson = DynamicJson.Parse(client["outdatacode"]);
                        im.uiHelper.setFactoryTimerDefault(Convert.ToInt32(clientjson.build_slot));
                        break;
                    }

                case RequestUrls.StartOperation:
                    {
                        dynamic clientjson = DynamicJson.Parse(client["outdatacode"]);
                        Models.AutoOperationInfo ao = null;
                        im.mainWindow.Dispatcher.Invoke(() =>
                        {
                            ao = new Models.AutoOperationInfo(Convert.ToInt32(clientjson.team_id), Convert.ToInt32(clientjson.operation_id));
                        });
                        
                        im.autoOperation.AddTimerStartOperation(ao);
                        break;
                    }

                case RequestUrls.FinishOperation:
                    {
                        dynamic clientjson = DynamicJson.Parse(client["outdatacode"]);
                        Models.AutoOperationInfo ao = im.autoOperation.FindOperation(Convert.ToInt32(clientjson.operation_id));

                        im.autoOperation.EndDelegate(ao);

                        break;
                    }

                case RequestUrls.AbortOperation:
                    {
                        dynamic clientjson = DynamicJson.Parse(client["outdatacode"]);
                        Models.AutoOperationInfo ao = im.autoOperation.FindOperation(Convert.ToInt32(clientjson.operation_id));
                        im.autoOperation.operationList.Remove(ao);
                        break;
                    }
            }

        }





    }
}
