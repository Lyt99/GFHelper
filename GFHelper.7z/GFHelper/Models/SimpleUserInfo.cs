﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GFHelper.Models
{
    class SimpleUserInfo
    {
        public static string host;
        public static string uid;
        public static string sign;
    }
}
