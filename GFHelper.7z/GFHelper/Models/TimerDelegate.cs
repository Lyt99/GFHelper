﻿using System.Windows.Controls;

namespace GFHelper.Models
{

    class TimerDelegate
    {
        public CommonModels.TimerDelegeFunction function;
        public TextBlock textBlock;
        public object a;
        public int start;
        public int last;
    }
}
