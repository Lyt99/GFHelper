﻿using System;

namespace GFHelper.Models
{
    public enum EffectGridType
    {
        ap = 7,
        crit = 5,
        dodge = 4,
        hit = 3,
        pow = 1,
        rate = 2,
        skill = 6
    }

}
